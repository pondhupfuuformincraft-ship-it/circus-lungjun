 "use client";
import {useEffect,useState} from "react";
import {supabase} from "../lib/supabase";
const demo=[1,2,3,4].map(i=>({name:"Player "+i,score:0,wins:0,difference:0,skull:0,ban_games:0}));
export default function Home(){
 const [rows,setRows]=useState(demo),[season,setSeason]=useState("Season 1"),[game,setGame]=useState(1),[status,setStatus]=useState("Demo mode");
 async function load(){const {data,error}=await supabase.from("circus_tables").select("id,season,current_game").order("created_at",{ascending:false}).limit(1).maybeSingle();if(error){setStatus("เชื่อมต่อไม่ได้");return}if(data){setSeason(data.season);setGame(data.current_game||1);setStatus("Realtime connected");const {data:p}=await supabase.from("circus_table_stats").select("score,wins,difference,skull,ban_games,circus_players(player_name)").eq("table_id",data.id);if(p?.length)setRows(p.map(x=>({name:x.circus_players?.player_name||"Player",...x})))}} 
 useEffect(()=>{load()},[]);
 const rank=[...rows].sort((a,b)=>b.score-a.score||b.wins-a.wins);
 return <main><header><div><small>ONE TWO GANG</small><h1>🎪 CIRCUS LUNGJUN</h1><p>Realtime Scoreboard</p></div><span>{status}</span></header>
 <section className="hero"><label>SEASON<input value={season} onChange={e=>setSeason(e.target.value)}/></label><label>GAME<b>{game}</b></label><button onClick={()=>setGame(x=>x+1)}>NEXT GAME</button></section>
 <section className="card"><h2>🏆 LIVE RANKING</h2><table><thead><tr><th>#</th><th>PLAYER</th><th>SCORE</th><th>WIN</th><th>DIFF</th><th>💀</th><th>🚫 BAN</th></tr></thead><tbody>{rank.map((r,i)=><tr key={r.name}><td>{i+1}</td><td><strong>{r.name}</strong></td><td>{r.score}</td><td>{r.wins}</td><td>{r.difference}</td><td>{r.skull}</td><td>{r.ban_games}</td></tr>)}</tbody></table></section>
 <section className="grid"><div className="card"><h3>🎮 GAME CONTROL</h3><button onClick={()=>setGame(x=>x+1)}>NEXT GAME</button><button className="dark" onClick={()=>setGame(x=>Math.max(1,x-1))}>PREVIOUS</button></div><div className="card"><h3>📋 STATUS</h3><p>Season: {season}</p><p>Game: {game}</p><p>Mode: OTF / League</p></div></section><footer>Circus Lungjun by OneTwo Gang</footer></main>
}