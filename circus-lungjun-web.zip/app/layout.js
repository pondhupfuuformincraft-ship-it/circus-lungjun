import "./globals.css";
export const metadata={title:"Circus Lungjun by OneTwo Gang"};
export default function Layout({children}){return <html lang="th"><body>{children}</body></html>}
